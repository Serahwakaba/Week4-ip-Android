package com.moringaschool.covid19tracker.network;

import com.moringaschool.covid19tracker.model.Countrymodel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface GetDataService {
    @GET("/countries")
    Call<List<Countrymodel>> getAllCountries();

}
